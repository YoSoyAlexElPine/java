package proyectojv.jrm.ap;

import static proyectojv.jrm.ap.Colores.ANSI_BLUE;
import static proyectojv.jrm.ap.Colores.ANSI_GREEN;
import static proyectojv.jrm.ap.Colores.ANSI_RED;

/**
 *
 * @author b03-10t
 */
public class Torre extends Escenario implements Dibujable{
    protected int nuPlanta,poder=100;
    protected String tipoEdificacion;
    protected boolean fortificada;
    protected int botin;
    protected Hostilidad hostilidad;
    public Torre() {
    }

    public Torre(int nuPlanta, boolean fortificada, int botin) {
        this.nuPlanta = nuPlanta;
        this.fortificada = fortificada;
        this.botin = botin;
    }

    public Torre(int nuPlanta, String tipoEdificacion, boolean fortificada, int botin) {
        this.nuPlanta = nuPlanta;
        this.tipoEdificacion = tipoEdificacion;
        this.fortificada = fortificada;
        this.botin = botin;
    }

    public Torre(int nuPlanta, String tipoEdificacion, boolean fortificada, int botin, Hostilidad hostilidad,int poder) {
        this.nuPlanta = nuPlanta;
        this.tipoEdificacion = tipoEdificacion;
        this.fortificada = fortificada;
        this.botin = botin;
        this.hostilidad = hostilidad;
        this.poder=poder;
    }

    public int getPoder() {
        return poder;
    }

    public Hostilidad getHostilidad() {
        return hostilidad;
    }
    
    

    public int getNuPlanta() {
        return nuPlanta;
    }

    public void setNuPlanta(int nuPlanta) {
        this.nuPlanta = nuPlanta;
    }

    public String getTipoEdificacion() {
        return tipoEdificacion;
    }

    public void setTipoEdificacion(String tipoEdificacion) {
        this.tipoEdificacion = tipoEdificacion;
    }

    public boolean isFortificada() {
        return fortificada;
    }

    public void setFortificada(boolean fortificada) {
        this.fortificada = fortificada;
    }

    public int getBotin() {
        return botin;
    }

    public void setBotin(int botin) {
        this.botin = botin;
    }

    @Override
    public int generarEventoAleatorio() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public String toString() {
        return "Torre{" + "nuPlanta=" + nuPlanta + ", poder=" + poder + ", tipoEdificacion=" + tipoEdificacion + ", fortificada=" + fortificada + ", botin=" + botin + ", hostilidad=" + hostilidad + '}';
    }

    public void dibujar(){
        Hostilidad valor = this.getHostilidad();
        switch (valor) {
            case HOSTIL -> {
                System.out.println(ANSI_RED+"    __ ");
                System.out.println(ANSI_RED+"   |  ");
                System.out.println(ANSI_RED+"   |");
            }
            case PASIVA -> {
                System.out.println(ANSI_BLUE+"    __ ");
                System.out.println(ANSI_BLUE+"   |  ");
                System.out.println(ANSI_BLUE+"   |");
            }
            case AMISTOSA -> {
                System.out.println(ANSI_GREEN+"    __ ");
                System.out.println(ANSI_GREEN+"   |  ");
                System.out.println(ANSI_GREEN+"   |");
            }
        }
        System.out.println("""
                               /^\\
                               |#|
                              |===|
                             .|0|""");
        for (int i = 0; i < nuPlanta; i++) {
            System.out.println("  | |");
        }
        System.out.println("""
                            =====
                           _||_||_
                           """);
    }
}
