
package proyectojv.jrm.ap;

/**
 *
 * @author b03-10t
 */
public enum Hostilidad {
    HOSTIL,PASIVA,AMISTOSA;
}
