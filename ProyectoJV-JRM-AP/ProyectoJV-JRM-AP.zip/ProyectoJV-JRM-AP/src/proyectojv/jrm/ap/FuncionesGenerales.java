/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyectojv.jrm.ap;

//import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author JoseVi
 */
public class FuncionesGenerales {

    // Funciones para la mazmorra        
    public static void menuMazmorra() {
        int opc, tamanioMazmorra = 5;
        Mazmorra[][] mazmorra;
        boolean salir = false;
        Scanner teclado = new Scanner(System.in);

        mazmorra = new Mazmorra[tamanioMazmorra][tamanioMazmorra];
        mazmorra = generarMazmorra(mazmorra);

        do {
            System.out.println("Introduce una opcion");
            System.out.println("1. Generar nueva aventura");
            System.out.println("2. Ver generacion actual");
            System.out.println("3. Dibujar mazmorra");
            System.out.println("0. Salir ");
            opc = teclado.nextInt();
            switch (opc) {
                case 1 -> {
                    mazmorra = new Mazmorra[tamanioMazmorra][tamanioMazmorra];
                    mazmorra = generarMazmorra(mazmorra);
                }
                case 2 -> {
                    System.out.println("=============================");
                    for (int i = 0; i < mazmorra.length; i++) {
                        for (int j = 0; j < mazmorra.length; j++) {
                            System.out.println(mazmorra[i][j].toString());
                            System.out.println("=============================");
                        }

                    }
                }
                case 3 -> {
                    for (int i = 0; i < mazmorra.length; i++) {
                        for (int j = 0; j < mazmorra.length; j++) {
                            mazmorra[i][j].dibujar();
                        }
                        System.out.println("");
                    }
                }
                case 0 -> {
                    salir = true;
                }
                default -> {
                    System.out.println("Opcion no disponible");
                }
            }
        } while (!salir);
    }

    public static Mazmorra[][] generarMazmorra(Mazmorra[][] mazmorra) {
        int piso = -1, aux;
        int MIN = 1, MAX = 3;
        for (int i = 0; i < mazmorra.length; i++) {
            for (int j = 0; j < mazmorra.length; j++) {
                if (i == 0 && j == 0) {
                    mazmorra[0][0] = new Mazmorra("Zona Inicial", Hostilidad.AMISTOSA);
                } else {
                    aux = (int) (Math.random() * (MAX - MIN + 1) + MIN);
                    switch (aux) {
                        case 1 -> {
                            mazmorra[i][j] = new Mazmorra(piso, "ZonaInicial", Hostilidad.AMISTOSA);
                        }
                        case 2 -> {
                            mazmorra[i][j] = new Mazmorra(piso, "ZonaInicial", Hostilidad.HOSTIL);
                        }
                        case 3 -> {
                            mazmorra[i][j] = new Mazmorra(piso, "ZonaInicial", Hostilidad.PASIVA);
                        }
                        default -> {
                            System.out.println("Error en el codigo");
                        }
                    }
                }

            }
            piso--;
        }
        return mazmorra;
    }

    public static void menuTorre() {
        Scanner teclado = new Scanner(System.in);
        int opc = 0, opc2 = 0,numPlantas,botin,aux;
        boolean fort;
        Torre torre1=null;
        System.out.println("""
                           
                           1. Generar torre aleatoria
                           2. Crear torre personalizada
                           """);
        try {
            System.out.print("Introduzca una opción: ");
            opc2 = teclado.nextInt();
            System.out.println("Opción introducida: " + opc2);
        } catch (Exception e) {
            System.out.println("Error: debe introducir un valor numérico.");
        }
        if (opc2 == 1) {
            torre1=generarTorre();
        } else {
            System.out.println("Introducce numero de plantas");
            numPlantas=teclado.nextInt();
            System.out.println("Introdicce el botin que tendra tu torre");
            botin=teclado.nextInt();
            System.out.println("Esta fortificada? 0 = no, 1 = si");
            aux=teclado.nextInt();
            if (aux==0) {fort=false;}else {fort=true;}
            torre1=new Torre(numPlantas,fort,botin);
        }

        do {
            System.out.println("""
                           === Elige Opcion ===
                           1. Inspeccionar
                           2. Saquear
                           3. Conquistar
                           4. Comerciar
                           5. Dibujar
                          
                           0. Salir
                               
                           """);
            try {
                System.out.print("Introduzca una opción: ");
                opc = teclado.nextInt();
                System.out.println("Opción introducida: " + opc);
            } catch (Exception e) {
                System.out.println("Error: debe introducir un valor numérico.");
            }

            switch (opc) {
                case 1->System.out.println(torre1.toString());
                case 5->torre1.dibujar();
            }
        } while (opc != 0);
    }

    private static Torre generarTorre() {
        int numPlanta, botin,poder;
        boolean fortificado=false;
        Hostilidad hostilidad = null;
        numPlanta=(int) (Math.random() * 10);
        botin=(int) (Math.random() * 10000);
        poder=(int) (Math.random()*1000);
        int aux=(int) (Math.random() * 1); if (aux==0) {fortificado=false;}else {fortificado=true;}
        int aux2=(int) (Math.random() * 2);
        switch (aux2){
            case 0->hostilidad=Hostilidad.AMISTOSA;
            case 1->hostilidad=Hostilidad.PASIVA;
            case 2->hostilidad=Hostilidad.HOSTIL;
        }
        Torre torre=new Torre(numPlanta,"Elfica",fortificado,botin,hostilidad,poder);
        return torre;
    }

}