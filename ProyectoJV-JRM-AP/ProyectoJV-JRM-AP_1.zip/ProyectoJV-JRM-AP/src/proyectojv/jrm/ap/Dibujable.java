
package proyectojv.jrm.ap;

/**
 *
 * @author JoseVi
 */
public interface Dibujable {
    public void dibujar();
}
