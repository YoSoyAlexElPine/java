/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyectojv.jrm.ap;

/**
 *
 * @author JoseVi
 */
public class eventoAleatorioMazmorra {
    
    public static void comprobarHostilidad(Hostilidad hostilidad,int nEvento){
        switch (hostilidad) {
            case AMISTOSA -> {
                
            }
            case PASIVA -> {
                
            }
            case HOSTIL-> {
                
            }
            default -> {
                System.out.println("Se ha producido un error");
            }
        }
    }
    
    
    public static void ejecutarEventoPasivo(int nEvento){
        
    }
    
    public static void ejecutarEventoHostil(int nEvento){
        
    }
    
    public static void ejecutarEventoAmistoso(int nEvento){
        
    }
}
