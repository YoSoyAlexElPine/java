package clases;


/**
 *
 * @author KRene
 */
public interface Dibujable {
    
    public void dibujar();
    
}
