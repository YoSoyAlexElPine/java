package clases;


/**
 *
 * @author KRene
 */
public enum Tipo {
    MINA,NUMERO,VACIA
}
