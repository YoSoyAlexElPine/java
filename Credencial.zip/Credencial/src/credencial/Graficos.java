package credencial;


public class Graficos {
    public static void menu(){
        System.out.println("""
                           -------------------------
                           - 1. Introducir usuario
                           - 2. Mostrar usuarios
                           - 3. Generar Aleatorios
                           - 4. Salir
                           -------------------------""");
    }
}
