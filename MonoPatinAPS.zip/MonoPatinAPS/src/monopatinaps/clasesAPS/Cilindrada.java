/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.java to edit this template
 */
package monopatinaps.clasesAPS;

/**
 *
 * @author b03-12t
 */
public enum Cilindrada {
    CC50,CC125,CC250,CC500,CC1000
}
